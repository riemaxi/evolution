cat data.evolution.$1 | ./report_frequency.py > report.frequency.$1
