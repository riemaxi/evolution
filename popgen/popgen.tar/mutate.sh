cat data.mutant.current | sort -R | ./mutate.py  > data.mutant
