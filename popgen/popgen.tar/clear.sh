rm -f report.frequency.*
rm -f data.*
