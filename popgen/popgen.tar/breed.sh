cat data.mutant | sort -R | ./breed.py > data.mutant.current
