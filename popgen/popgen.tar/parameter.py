trials = 10
population_size = 100
haplotypes = 2
ploidy = 2
default_fitness = 1.0
fitness_data = 'data.fitness'

max_generation = 100

mutate_max = 30

